BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "learning_logs_topic" (
	"id"	integer NOT NULL,
	"text"	varchar(200) NOT NULL,
	"date_added"	datetime NOT NULL,
	"owner_id"	integer NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("owner_id") REFERENCES "auth_user"("id") DEFERRABLE INITIALLY DEFERRED
);
INSERT INTO "learning_logs_topic" VALUES (3,'Xadrez','2024-10-25 14:59:48.699450',4);
INSERT INTO "learning_logs_topic" VALUES (4,'Programação','2024-10-25 18:41:19.342407',4);
INSERT INTO "learning_logs_topic" VALUES (5,'Curso de Python','2024-10-29 17:31:38.944060',4);
INSERT INTO "learning_logs_topic" VALUES (6,'Matemática','2024-10-31 18:41:36.798358',4);
INSERT INTO "learning_logs_topic" VALUES (7,'Inglês','2024-10-31 18:42:20.894094',4);
INSERT INTO "learning_logs_topic" VALUES (8,'Flask','2025-01-24 14:23:40.356825',5);
INSERT INTO "learning_logs_topic" VALUES (9,'IA','2025-01-24 14:28:59.589121',4);
CREATE INDEX IF NOT EXISTS "learning_logs_topic_owner_id_67ecce32" ON "learning_logs_topic" (
	"owner_id"
);
COMMIT;
